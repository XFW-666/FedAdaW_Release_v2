#!/usr/bin/env python3
"""Label-leakage audit.

For every corpus we fit the best single-feature threshold classifier (a decision stump
over each of the seven indicators, with the optimal threshold and polarity) and report its
balanced accuracy.  A value close to 1 would mean the label is recoverable from one input
feature, so the federated comparison would be measuring that fact rather than the
aggregation rule.

Reads the preprocessed corpora shipped in data/preprocessed/.
"""
import sys
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import balanced_accuracy_score

BASE = Path(__file__).resolve().parent.parent
PRE = BASE / "data" / "preprocessed"
FEATS = ['engagement_volume', 'engagement_consistency', 'performance_level',
         'performance_trend', 'effort_per_unit', 'prior_difficulty',
         'demographic_advantage']


def stump_ba(x, y):
    """Balanced accuracy of the best one-threshold classifier on a single feature."""
    best = 0.0
    for q in np.unique(np.quantile(x, np.linspace(0.02, 0.98, 49))):
        for pol in (1, -1):
            pred = (pol * (x > q)).astype(int)
            if len(np.unique(pred)) < 2:
                continue
            best = max(best, balanced_accuracy_score(y, pred))
    return best


CHARACTERISATION_ONLY = {"HigherEdEval"}


def main():
    worst = 0.0
    worst_modelled = 0.0
    for f in sorted(PRE.glob("*.csv")):
        df = pd.read_csv(f)
        if "label" not in df.columns:
            continue
        y = df["label"].to_numpy()
        rows = sorted(((stump_ba(df[c].to_numpy(float), y), c) for c in FEATS
                       if c in df.columns), reverse=True)
        worst = max(worst, rows[0][0])
        if f.stem not in CHARACTERISATION_ONLY:
            worst_modelled = max(worst_modelled, rows[0][0])
        flag = "   <-- label recoverable from one feature" if rows[0][0] > 0.90 else ""
        print(f"{f.stem:<22} n={len(y):<6} positive rate={y.mean():.3f}  "
              f"best single feature: {rows[0][1]}={rows[0][0]:.4f} | "
              f"second: {rows[1][1]}={rows[1][0]:.4f}{flag}")
    print(f"\nmax single-feature balanced accuracy, corpora used for modelling: "
          f"{worst_modelled:.4f}")
    print(f"max over all corpora including the characterisation-only corpus: {worst:.4f}")
    print("HigherEdEval is characterisation only: 145 records leave two clients under the "
          "partitioning and its outcome variable cannot be separated from its predictors.")


if __name__ == '__main__':
    main()
