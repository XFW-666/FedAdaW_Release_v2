#!/usr/bin/env python3
"""FedAdaW v10 extra stages added for the revision:

  fair   -- per-client local-holdout fairness 
  cost2  -- wall-clock / transmitted bytes vs client count K and model width
  tune   -- beta / lambda selection on a validation split disjoint from test

usage: extra_v10.py <stage> <tag> [corpora_csv] [seeds_csv] [n_rounds]
"""
from pathlib import Path
import importlib.util, sys, json, os, time, gc
import numpy as np
from sklearn.model_selection import train_test_split

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

BASE = Path(__file__).resolve().parent.parent      # repository root
spec = importlib.util.spec_from_file_location("pv12", Path(__file__).resolve().parent / "pipeline_v12.py")
m = importlib.util.module_from_spec(spec)
sys.modules["pv12"] = m
spec.loader.exec_module(m)

stage = sys.argv[1]
tag = sys.argv[2]
corp = sys.argv[3].split(",") if len(sys.argv) > 3 and sys.argv[3] else None
if len(sys.argv) > 4 and sys.argv[4]:
    m.SEEDS = [int(x) for x in sys.argv[4].split(",")]
if len(sys.argv) > 5 and sys.argv[5]:
    m.N_ROUNDS = int(sys.argv[5])
if os.environ.get("OUTROOT"):
    m.OUT = m.BASE / os.environ["OUTROOT"]
    m.OUT.mkdir(exist_ok=True)
OUT = m.OUT / tag
OUT.mkdir(parents=True, exist_ok=True)
m.OUT = OUT
t0 = time.time()

corpora = m.build_corpora()

# load the validation-selected per-corpus configuration
for root in (m.OUT.parent, m.BASE / "results"):
    for f in sorted(root.glob("**/tune_v12_*.json")):
        try:
            d = json.load(open(f, encoding="utf-8"))
            m.CFG[d["corpus"]] = d["cfg"]
        except Exception as e:
            print("cfg load skip", f, e, flush=True)
print("CFG:", json.dumps(m.CFG, sort_keys=True), flush=True)

NR = int(os.environ.get('NR', str(m.N_ROUNDS)))          # rounds for fair/tune
NR2 = int(os.environ.get('NR2', '5'))                    # rounds for cost2


# ---------------------------------------------------------------- fairness
def prep_local_holdout(name, corpora, seed, frac=0.25):
    """Same global test split as prep_corpus, but each client additionally keeps
    a local holdout that is never used for local training.  Per-client accuracy
    on that holdout measures who the aggregation serves."""
    c = corpora[name]
    X, y = c['X'], c['y']
    K = m.K_MAP.get(name, 20)
    all_idx = np.arange(len(y))
    tr_idx, te_idx = train_test_split(all_idx, test_size=m.TEST_FRAC.get(name, 0.25),
                                      random_state=seed, stratify=y)
    sub = m.part_dirichlet(y[tr_idx], K, m.ALPHA_DIR, seed)
    clients = []
    for s in sub:
        gidx = tr_idx[s]
        if len(gidx) < 25:          # need >=10 for local training and >=5 for the holdout
            continue
        yy = y[gidx]
        cnt = np.bincount(yy, minlength=2)
        strat = yy if cnt.min() >= 2 else None
        try:
            a, b = train_test_split(gidx, test_size=frac, random_state=seed + 11, stratify=strat)
        except Exception:
            a, b = train_test_split(gidx, test_size=frac, random_state=seed + 11)
        if len(a) >= m.MIN_CLIENT and len(b) >= 5:
            clients.append((np.asarray(a), np.asarray(b)))
    Xtr = [X[a] for a, b in clients]
    ytr = [y[a] for a, b in clients]
    hold = [(X[b], y[b]) for a, b in clients]
    return Xtr, ytr, hold, X[te_idx], y[te_idx]


def per_client_metrics(g, hold):
    bas, sizes = [], []
    for Xh, yh in hold:
        pr = m.pred(g, Xh) if hasattr(m, 'pred') else None
        if pr is None:
            import torch
            g.eval()
            with torch.no_grad():
                pr = g(torch.FloatTensor(Xh)).argmax(1).numpy()
        from sklearn.metrics import balanced_accuracy_score
        bas.append(float(balanced_accuracy_score(yh, pr)))
        sizes.append(int(len(yh)))
    return np.array(bas), np.array(sizes)


def fair_experiments(corpora):
    out = {}
    names = corp or ['StudentDropout', 'OnlineTutorBehaviour']
    for name in names:
        dim = corpora[name]['X'].shape[1]
        for s in m.SEEDS:
            Xtr, ytr, hold, Xte, yte = prep_local_holdout(name, corpora, s)
            for meth in ['FedAvg', 'FedOpt', 'FedAdaW']:
                g, _, _ = m.run(meth, Xtr, ytr, dim, s, n_rounds=NR,
                                **(m.cfg_for(name) if meth == 'FedAdaW' else {}))
                ba, sz = per_client_metrics(g, hold)
                o = np.argsort(ba)
                rec = dict(n_clients=int(len(ba)),
                           mean=float(ba.mean()), std=float(ba.std(ddof=1)) if len(ba) > 1 else 0.0,
                           minimum=float(ba.min()), q25=float(np.percentile(ba, 25)),
                           median=float(np.median(ba)), q75=float(np.percentile(ba, 75)),
                           maximum=float(ba.max()),
                           worst5=float(ba[o][:max(1, len(ba) // 5)].mean()),
                           best5=float(ba[o][-max(1, len(ba) // 5):].mean()),
                           iqr=float(np.percentile(ba, 75) - np.percentile(ba, 25)),
                           gap=float(ba.max() - ba.min()),
                           corr_size_ba=float(np.corrcoef(sz, ba)[0, 1]) if len(ba) > 2 else float('nan'),
                           per_client=[float(x) for x in ba],
                           sizes=[int(x) for x in sz])
                out.setdefault(f"{name}|{meth}", []).append(rec)
                print(f"[fair] {name} s{s} {meth} min={rec['minimum']:.3f} "
                      f"med={rec['median']:.3f} worst5={rec['worst5']:.3f}", flush=True)
    return out


# ------------------------------------------------------------------- cost
def _mlp_with(hidden):
    orig = m.MLP
    def factory(d, h=hidden):
        return orig(d, h=h)
    return factory


def cost2_experiments(corpora):
    out = {}
    name = (corp or ['StudentDropout'])[0]
    dim = corpora[name]['X'].shape[1]
    orig_mlp = m.MLP
    for hidden in [(64, 32), (128, 64), (256, 128)]:
        m.MLP = _mlp_with(hidden)
        for K in [10, 20, 50]:
            Xtr, ytr, Xva, yva, Xte, yte, ncl = m.prep_corpus(name, corpora, K, 'dir0.1', 42)
            for meth in ['FedAvg', 'FedAdaW']:
                gc.collect()
                t1 = time.time()
                g, _, _ = m.run(meth, Xtr, ytr, dim, 42, n_rounds=NR2)
                dt = time.time() - t1
                n_par = int(sum(p.numel() for p in g.parameters()))
                rec = dict(hidden=list(hidden), K=K, clients_retained=int(ncl),
                           params=n_par, seconds_5_rounds=float(dt),
                           ms_per_round=float(dt / 5 * 1000),
                           bytes_5_rounds=int(5 * ncl * n_par * 4),
                           bytes_per_round=int(ncl * n_par * 4))
                out[f"{name}|h{hidden[0]}|K{K}|{meth}"] = rec
                print(f"[cost2] h={hidden} K={K} {meth} {dt:.1f}s", flush=True)
    m.MLP = orig_mlp
    return out


# ------------------------------------------------------------------- tune
def tune_experiments(corpora):
    """Select beta and lambda on the validation split only (never on test)."""
    out = {}
    name = (corp or ['StudentDropout'])[0]
    dim = corpora[name]['X'].shape[1]
    betas = [0.25, 0.5, 1.0]
    lams = [0.0, 0.01, 0.05]
    for s in m.SEEDS:
        Xtr, ytr, Xva, yva, Xte, yte, ncl = m.prep_corpus(name, corpora, None, 'dir0.1', s)
        for b in betas:
            for lam in lams:
                m.BETA = b
                m.LAM_ALIGN = lam
                g = m._run_variant('full', Xtr, ytr, dim, s, n_rounds=NR)
                v = m.ev(g, Xva, yva)
                t = m.ev(g, Xte, yte)
                out.setdefault(f"{name}|b{b}|l{lam}", []).append(
                    dict(val_balanced_accuracy=v['balanced_accuracy'],
                         val_accuracy=v['accuracy'],
                         test_balanced_accuracy=t['balanced_accuracy'],
                         test_accuracy=t['accuracy'], seed=s))
                print(f"[tune] {name} s{s} beta={b} lam={lam} "
                      f"valBA={v['balanced_accuracy']:.4f} testBA={t['balanced_accuracy']:.4f}", flush=True)
    m.BETA, m.LAM_ALIGN = 0.5, 0.01
    return out


if stage == 'fair':
    json.dump(fair_experiments(corpora), open(OUT / f"fair_{tag}.json", "w"), default=float)
elif stage == 'cost2':
    json.dump(cost2_experiments(corpora), open(OUT / f"cost2_{tag}.json", "w"), indent=2, default=float)
elif stage == 'tune':
    json.dump(tune_experiments(corpora), open(OUT / f"tune_{tag}.json", "w"), default=float)
else:
    raise SystemExit("unknown stage " + stage)
print(f"[extra] {stage}/{tag} done {time.time()-t0:.0f}s", flush=True)
