#!/usr/bin/env python3
"""Coordinate search of FedAdaW's hyperparameters on the validation split only.

usage: tune_v11.py <corpus> <seeds_csv> <out_tag>
Writes rev3_out/tune_v12_<corpus>.json = {"corpus": cfg, "history": {...}}
"""
from pathlib import Path
import importlib.util, sys, json, os, time

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

BASE = Path(__file__).resolve().parent.parent      # repository root
spec = importlib.util.spec_from_file_location("pv12", Path(__file__).resolve().parent / "pipeline_v12.py")
m = importlib.util.module_from_spec(spec)
sys.modules["pv12"] = m
spec.loader.exec_module(m)

corpus = sys.argv[1]
seeds = [int(x) for x in sys.argv[2].split(",")] if len(sys.argv) > 2 and sys.argv[2] else [42, 43]
tag = sys.argv[3] if len(sys.argv) > 3 else corpus
if os.environ.get("OUTROOT"):
    m.OUT = m.BASE / os.environ["OUTROOT"]
    m.OUT.mkdir(exist_ok=True)
OUT = m.OUT / tag
OUT.mkdir(parents=True, exist_ok=True)
m.OUT = OUT

corpora = m.build_corpora()
hist = {}
t0 = time.time()

for stage in ['beta', 'server', 'lam']:
    rows = m.tune_stage(corpora, stage, corpora_to_tune=[corpus], seeds=seeds)
    hist[stage] = rows
    # select the best configuration for this stage on the validation split
    best, bkey = -1.0, None
    for key, rr in rows.items():
        v = sum(r['val_ba'] for r in rr) / len(rr)
        if v > best:
            best, bkey = v, key
    cfg = rows[bkey][0]['cfg']
    m.CFG[corpus] = dict(cfg)
    print(f"[stage {stage}] {corpus}: best valBA={best:.4f} cfg={cfg}  ({time.time()-t0:.0f}s)",
          flush=True)

json.dump(dict(corpus=corpus, cfg=m.CFG[corpus], history=hist),
          open(OUT / f"tune_v12_{corpus}.json", "w"), indent=1, default=float)
print(f"[tune_v12] {corpus} done {time.time()-t0:.0f}s -> {m.CFG[corpus]}", flush=True)
