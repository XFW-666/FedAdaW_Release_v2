"""Figures for the revised manuscript: six multi-panel composites, no bar charts.

usage: figs_v12.py <merged_dir> <out_dir>
"""
import json, sys
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib.gridspec import GridSpec

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else
            Path(__file__).resolve().parent.parent / "results" / "merged")
FIGD = Path(sys.argv[2] if len(sys.argv) > 2 else
            Path(__file__).resolve().parent.parent / "figures")
FIGD.mkdir(parents=True, exist_ok=True)
DPI = 300

plt.rcParams.update({
    'font.family': 'DejaVu Sans', 'font.size': 8, 'axes.titlesize': 8.5,
    'axes.labelsize': 8, 'axes.linewidth': 0.7, 'xtick.labelsize': 7.2,
    'ytick.labelsize': 7.2, 'legend.fontsize': 6.6, 'figure.dpi': DPI,
    'savefig.dpi': DPI, 'axes.grid': True, 'grid.alpha': 0.22, 'grid.linewidth': 0.5,
    'savefig.bbox': 'tight',
})

METHODS = ['FedAvg', 'FedProx', 'FedDyn', 'SCAFFOLD', 'FedOpt', 'FedAvgM',
           'FedNolowe', 'MOON', 'FedAdaW']
MCOL = {'FedAdaW (corr.)': '#B71C1C', 'FedAvg': '#4C4C4C', 'FedProx': '#8C6D31', 'FedDyn': '#2E7D32',
        'SCAFFOLD': '#00695C', 'FedOpt': '#1565C0', 'FedAvgM': '#6A1B9A',
        'FedNolowe': '#C62828', 'MOON': '#EF6C00', 'FedAdaW': '#111111'}
SHORT = {'OnlineTutorBehaviour': 'Tutoring', 'StudentDropout': 'Dropout',
         'SecondaryGrades': 'Secondary', 'EntranceExam': 'Entrance',
         'CrossCorpus': 'CrossCorpus'}
CORP_ORDER = ['StudentDropout', 'SecondaryGrades', 'EntranceExam',
              'OnlineTutorBehaviour', 'CrossCorpus']


def load(name):
    f = ROOT / f"{name}.json"
    return json.load(open(f, encoding='utf-8')) if f.exists() else {}


def vals(res, corpus, method, metric='balanced_accuracy'):
    return np.array([x[metric] for x in res.get(f"{corpus}|{method}", [])
                     if not (isinstance(x[metric], float) and np.isnan(x[metric]))], float)


def tci(v):
    from scipy import stats as st
    v = np.asarray(v, float)
    if len(v) < 2:
        return (float(v.mean()) if len(v) else np.nan), 0.0
    se = v.std(ddof=1) / np.sqrt(len(v))
    return float(v.mean()), float(st.t.ppf(0.975, len(v) - 1) * se)


# ------------------------------------------------------------------ figure 1
def fig1(res, meta):
    fig = plt.figure(figsize=(7.1, 3.1))
    gs = GridSpec(1, 2, width_ratios=[1.15, 1.0], wspace=0.34)

    ax = fig.add_subplot(gs[0, 0]); ax.axis('off')
    ax.set_xlim(0, 10); ax.set_ylim(0, 10)
    ax.text(0.1, 9.55, '(a) Federated protocol', fontsize=8.2, weight='bold')
    box = lambda x, y, w, h, t, fc: (
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.12",
                                    fc=fc, ec='#333333', lw=0.7)),
        ax.text(x + w / 2, y + h / 2, t, ha='center', va='center', fontsize=6.3))
    src = ['dropout\ncohort', 'secondary\ngrades', 'tutoring\nlogs', 'entrance\nexam']
    for i, s in enumerate(src):
        box(0.15, 7.0 - i * 1.45, 2.0, 1.15, s, '#E8F1FA')
    box(2.75, 5.6, 2.35, 3.05,
        'seven shared\nindicators\nno padding\nper-source target', '#FFF6DA')
    box(5.7, 5.6, 2.15, 3.05, 'local clients\nraw records\nstay local', '#EAF5EA')
    for i in range(4):
        ax.add_patch(FancyArrowPatch((2.2, 7.55 - i * 1.45), (2.68, 7.2 - i * 0.55),
                                     arrowstyle='-|>', mutation_scale=6.5, lw=0.7, color='#555555'))
    ax.add_patch(FancyArrowPatch((5.15, 7.1), (5.62, 7.1), arrowstyle='-|>',
                                 mutation_scale=6.5, lw=0.7, color='#555555'))
    box(2.75, 2.1, 5.1, 2.35,
        'server: sliced Wasserstein-2\ncoefficients from distance,\nsize and local fit\n'
        '+ server momentum', '#F2EAF7')
    ax.add_patch(FancyArrowPatch((6.75, 5.55), (6.75, 4.5), arrowstyle='<|-|>',
                                 mutation_scale=6.5, lw=0.7, color='#555555'))
    ax.text(0.1, 1.25, 'One global stratified split per corpus and seed;\n'
                       'clients are formed from the training part only, so the\n'
                       'test split is identical for every method.\n'
                       'Partitions: Dirichlet(0.1), Dirichlet(0.5), shard.',
            fontsize=6.1, va='top')

    ax = fig.add_subplot(gs[0, 1])
    ax.set_title('(b) Corpora after preprocessing', fontsize=8.2, weight='bold')
    rows = []
    for c in CORP_ORDER:
        ks = sorted([k for k in meta if k.startswith(c + '|')])
        if not ks:
            continue
        rows.append((c, np.mean([meta[k]['majority'] for k in ks]),
                     np.mean([meta[k]['n_test'] for k in ks]),
                     np.mean([meta[k]['clients'] for k in ks])))
    xs = [r[1] for r in rows]; ys = [r[2] for r in rows]
    sz = [max(30, min(700, r[3] * 26)) for r in rows]
    ax.scatter(xs, ys, s=sz, c='#1565C0', alpha=0.5, edgecolor='#0D3C6E', lw=0.7, zorder=3)
    place = {'CrossCorpus': (8, -14, 'left'), 'Tutoring': (9, 4, 'left'),
             'Dropout': (-9, -6, 'right'), 'Entrance': (-9, 5, 'right'),
             'Secondary': (-9, 5, 'right')}
    for (c, maj, nt, k), x, y in zip(rows, xs, ys):
        dx, dy, ha = place.get(c, (6, 6, 'left'))
        ax.annotate(f"{SHORT.get(c, c)}\n{int(round(k))} clients", (x, y), fontsize=6.0,
                    xytext=(dx, dy), textcoords='offset points', ha=ha)
    ax.set_xlabel('majority-class rate of the test split')
    ax.set_ylabel('test records')
    ax.set_yscale('log')
    ax.set_ylim(min(ys) * 0.75, max(ys) * 2.6)
    ax.set_xlim(0.44, 0.93)
    ax.axvline(0.5, color='#999999', ls=':', lw=0.8)
    ax.text(0.508, min(ys) * 0.85, 'balanced', fontsize=6,
            color='#777777', rotation=90)
    fig.savefig(FIGD / 'fig1_study_design.png')
    plt.close(fig)
    print('fig1 ok')


# ------------------------------------------------------------------ figure 2
def fig2(res, meta, curves, var=None):
    var = var or {}
    corpora = [c for c in CORP_ORDER if any(k.startswith(c + '|') for k in res)]
    fig = plt.figure(figsize=(7.2, 4.4))
    gs = GridSpec(2, len(corpora), height_ratios=[1.0, 0.8], hspace=0.62, wspace=0.16)

    for j, c in enumerate(corpora):
        ax = fig.add_subplot(gs[0, j])
        ms = [m for m in METHODS if f"{c}|{m}" in res]
        if f"{c}|size_dist" in var:
            ms = ms + ['FedAdaW (corr.)']
        yy = np.arange(len(ms))[::-1]
        for y, m in zip(yy, ms):
            v = (np.array([x['balanced_accuracy'] for x in var[f"{c}|size_dist"]], float)
                 if m == 'FedAdaW (corr.)' else vals(res, c, m))
            mu, h = tci(v)
            ax.plot([mu - h, mu + h], [y, y], color=MCOL[m], lw=1.25, alpha=0.85,
                    solid_capstyle='round')
            ax.plot([mu], [y], 'o', color=MCOL[m], ms=3.2, zorder=3)
            if m == 'FedAdaW':
                ax.axhspan(y - 0.45, y + 0.45, color='#111111', alpha=0.08, zorder=0)
        ks = sorted([k for k in meta if k.startswith(c + '|')])
        if ks:
            maj = np.mean([meta[k]['majority'] for k in ks])
            ax.axvline(maj, color='#B71C1C', ls='--', lw=0.8)
            ax.text(maj, 0.015, f'{maj:.2f}', transform=ax.get_xaxis_transform(),
                    fontsize=5.2, color='#B71C1C', ha='center', va='bottom')
        ax.set_yticks(yy)
        ax.set_yticklabels(ms if j == 0 else [''] * len(ms), fontsize=6.6)
        ax.set_title(f"{SHORT.get(c, c)}", fontsize=7.6)
        ax.set_xlim(0.3, 1.03)
        if j == 0:
            ax.set_xlabel('balanced accuracy', fontsize=7)

    for j, c in enumerate(['StudentDropout', 'OnlineTutorBehaviour']):
        ax = fig.add_subplot(gs[1, 2 * j:2 * j + 2])
        ks = [k for k in curves if k.startswith(c + '|')]
        if ks:
            L = min(len(curves[k]) for k in ks)
            A = np.vstack([np.array(curves[k][:L], float) for k in ks])
            x = np.arange(L)
            ax.plot(x, A.mean(0), color='#111111', lw=1.3)
            ax.fill_between(x, A.mean(0) - A.std(0), A.mean(0) + A.std(0),
                            color='#111111', alpha=0.15, lw=0)
            ax.axhline(np.mean([meta[k]['majority'] for k in meta
                                if k.startswith(c + '|')]), color='#B71C1C',
                       ls='--', lw=0.8)
        ax.set_xlabel('communication round', fontsize=7)
        ax.set_title(f"{SHORT.get(c, c)} (validation)", fontsize=7.2)
        if j == 0:
            ax.set_ylabel('balanced accuracy\n(validation)', fontsize=7)
    fig.suptitle('Mean balanced accuracy with 95% confidence intervals over ten seeds, final '
                 'round (top), and the validation curve of the proposed rule (bottom)',
                 fontsize=8.0, y=1.0)
    fig.savefig(FIGD / 'fig2_main.png')
    plt.close(fig)
    print('fig2 ok')


# ------------------------------------------------------------------ figure 3
def fig3(het):
    corpora = sorted({k.split('|')[0] for k in het})
    protocols = ['dir0.1', 'dir0.5', 'shard']
    plab = ['$\\alpha$=0.1', '$\\alpha$=0.5', 'shard']
    ms = ['FedAvg', 'FedOpt', 'FedDyn', 'FedAdaW']
    fig, axes = plt.subplots(1, 2 * len(corpora), figsize=(7.4, 2.5))
    if len(corpora) == 1:
        axes = np.array([axes])
    for ci, c in enumerate(corpora):
        ax = axes[2 * ci]
        for m in ms:
            xs, mus, hs = [], [], []
            for pi, pr in enumerate(protocols):
                v = vals(het, f"{c}|{pr}", m) if False else \
                    np.array([x['balanced_accuracy'] for x in het.get(f"{c}|{pr}|{m}", [])])
                if not len(v):
                    continue
                mu, h = tci(v)
                xs.append(pi); mus.append(mu); hs.append(h)
            ax.errorbar(xs, mus, yerr=hs, marker='o', ms=3.2, lw=1.0, capsize=1.8,
                        color=MCOL[m], label=m if ci == 0 else None)
        ax.set_xticks(range(3)); ax.set_xticklabels(plab, fontsize=6.6)
        ax.set_title(SHORT.get(c, c), fontsize=7.8)
        if ci == 0:
            ax.set_ylabel('balanced accuracy')
        ax = axes[2 * ci + 1]
        base = {pr: np.mean([x['balanced_accuracy'] for x in het.get(f"{c}|{pr}|FedAvg", [])])
                for pr in protocols if het.get(f"{c}|{pr}|FedAvg")}
        for m in ['FedOpt', 'FedDyn', 'FedAdaW']:
            d, x = [], []
            for pi, pr in enumerate(protocols):
                k = f"{c}|{pr}|{m}"
                if k in het and pr in base:
                    d.append(np.mean([y['balanced_accuracy'] for y in het[k]]) - base[pr])
                    x.append(pi)
            if d:
                ax.plot(x, d, marker='s', ms=3.0, lw=1.0, color=MCOL[m],
                        label=m if ci == 0 else None)
        ax.axhline(0, color='#444444', lw=0.8)
        ax.set_xticks(range(3)); ax.set_xticklabels(plab, fontsize=6.6)
        ax.set_title(f"{SHORT.get(c, c)}: change vs FedAvg", fontsize=7.8)
        if ci == 0:
            ax.set_ylabel('$\\Delta$ balanced accuracy')
    axes[0].legend(frameon=False, loc='lower left', ncol=2, fontsize=6.2)
    fig.tight_layout()
    fig.savefig(FIGD / 'fig3_heterogeneity.png')
    plt.close(fig)
    print('fig3 ok')


# ------------------------------------------------------------------ figure 4
def fig4(abl, diag):
    corpora = sorted({k.split('|')[0] for k in abl})
    variants = ['no_w2', 'dist_euclid', 'dist_cosine', 'loss_only', 'size_only',
                'size_loss', 'size_dist', 'dist_only', 'no_momentum', 'no_scaling',
                'mom_only']
    fig = plt.figure(figsize=(7.4, 5.6))
    gs = GridSpec(2, 2, height_ratios=[1.0, 0.82], hspace=0.46, wspace=0.3)

    ax = fig.add_subplot(gs[0, 0])
    yy = np.arange(len(variants))[::-1]
    for y, v in zip(yy, variants):
        for c, mk, col in zip(corpora, ['o', 's'],
                              ['#1565C0', '#C62828']):
            full = vals(abl, c, 'full'); cur = vals(abl, c, v)
            n = min(len(full), len(cur))
            if not n:
                continue
            d = cur[:n] - full[:n]
            mu, h = tci(d)
            off = 0.15 if mk == 's' else -0.15
            ax.errorbar(mu, y + off, xerr=h, marker=mk, ms=2.8, lw=1.0, capsize=1.6,
                        color=col)
    ax.axvline(0, color='#333333', lw=0.9)
    ax.set_yticks(yy); ax.set_yticklabels(variants, fontsize=6.8)
    ax.set_xlabel('$\\Delta$ balanced accuracy vs full model', fontsize=7)
    ax.set_title('(a) Component ablation (paired, ten seeds)', fontsize=8.2, weight='bold')
    ax.legend(handles=[Line2D([], [], marker='o', ls='', color='#1565C0', label=SHORT[corpora[0]]),
                       Line2D([], [], marker='s', ls='', color='#C62828',
                              label=SHORT[corpora[1]] if len(corpora) > 1 else '')],
              frameon=False, loc='upper left', fontsize=6.2)

    ax = fig.add_subplot(gs[0, 1])
    fam = ['full', 'no_w2', 'dist_euclid', 'dist_cosine', 'loss_only', 'size_only']
    lab = ['full\n(sliced W2)', 'no dist.\n(size x loss)', 'Euclid.', 'cosine',
           'loss only', 'size only']
    w = 0.36
    for i, c in enumerate(corpora):
        mus, hs = [], []
        for v in fam:
            mu, h = tci(vals(abl, c, v)); mus.append(mu); hs.append(h)
        xs = np.arange(len(fam)) + (i - 0.5) * w
        ax.errorbar(xs, mus, yerr=hs, marker='o', ls='', ms=3.2, lw=1.0, capsize=1.8,
                    color='#1565C0' if i == 0 else '#C62828', label=SHORT.get(c, c))
    ax.set_xticks(range(len(fam))); ax.set_xticklabels(lab, fontsize=5.6)
    ax.set_ylabel('balanced accuracy', fontsize=7)
    ax.set_title('(b) Which weighting term carries the effect', fontsize=8.2, weight='bold')
    ax.legend(frameon=False, loc='lower right', fontsize=6.2)

    ks = sorted(diag.keys())
    for slot, key, ylab, ttl in [
            (gs[1, 0], 'w_cv', 'coefficient of variation of $\\alpha$',
             '(c) The weights do discriminate clients'),
            (gs[1, 1], 'dist_cv', 'relative spread of pairwise $W_2$',
             '(d) Clients stay distributionally apart')]:
        ax = fig.add_subplot(slot)
        for c, col in zip(['StudentDropout', 'OnlineTutorBehaviour', 'CrossCorpus'],
                          ['#1565C0', '#C62828', '#2E7D32']):
            arrs = [np.array(diag[k].get(key, []), float).ravel()
                    for k in ks if k.startswith(c + '|')]
            arrs = [a for a in arrs if len(a)]
            if not arrs:
                continue
            L = min(len(a) for a in arrs)
            A = np.vstack([a[:L] for a in arrs])
            ax.plot(np.arange(L), A.mean(0), color=col, lw=1.2, label=SHORT.get(c, c))
            ax.fill_between(np.arange(L), A.mean(0) - A.std(0), A.mean(0) + A.std(0),
                            color=col, alpha=0.18, lw=0)
        ax.set_xlabel('communication round', fontsize=7)
        ax.set_ylabel(ylab, fontsize=7)
        ax.set_title(ttl, fontsize=8.2, weight='bold')
        ax.legend(frameon=False, ncol=3, loc='upper right', fontsize=6.0)
    fig.savefig(FIGD / 'fig4_ablation.png')
    plt.close(fig)
    print('fig4 ok')


# ------------------------------------------------------------------ figure 5
def fig5(fair):
    corpora = sorted({k.split('|')[0] for k in fair})
    ms = ['FedAvg', 'FedOpt', 'FedAdaW']
    fig, axes = plt.subplots(1, 3, figsize=(7.4, 2.7))
    ax = axes[0]
    data, labs, cols = [], [], []
    for c in corpora:
        for m in ms:
            a = []
            for rec in fair.get(f"{c}|{m}", []):
                a.extend(rec['per_client'])
            if a:
                data.append(a)
                labs.append(f"{SHORT.get(c, c)[:4]}\n{m.replace('Fed', '')}")
                cols.append(MCOL[m])
    parts = ax.violinplot(data, showextrema=False, widths=0.85)
    for b, col in zip(parts['bodies'], cols):
        b.set_facecolor(col); b.set_alpha(0.33); b.set_edgecolor('none')
    rs = np.random.RandomState(0)
    for i, a in enumerate(data, 1):
        ax.plot(rs.normal(i, 0.045, len(a)), a, 'o', ms=1.5, color=cols[i - 1], alpha=0.6)
        ax.plot([i], [np.mean(a)], '_', color='#111111', ms=8, mew=1.2)
    ax.set_xticks(range(1, len(labs) + 1))
    ax.set_xticklabels(labs, fontsize=5.2, rotation=30, ha='right')
    ax.set_ylabel('per-client balanced accuracy', fontsize=7)
    ax.set_title('(a) Who the federation serves', fontsize=8.2, weight='bold')

    ax = axes[1]
    for c, ls in zip(corpora, ['-', '--']):
        for m in ms:
            a = []
            for rec in fair.get(f"{c}|{m}", []):
                a.extend(rec['per_client'])
            if not a:
                continue
            x = np.sort(np.array(a))
            ax.plot(x, np.arange(1, len(x) + 1) / len(x), ls, color=MCOL[m], lw=1.1,
                    label=f"{SHORT.get(c, c)} {m}")
    ax.set_xlabel('per-client balanced accuracy', fontsize=7)
    ax.set_ylabel('ECDF', fontsize=7)
    ax.set_title('(b) Distribution of client outcomes', fontsize=8.2, weight='bold')
    ax.legend(frameon=False, fontsize=5.2, loc='upper left', ncol=1)

    ax = axes[2]
    keys = ['minimum', 'worst5', 'q25', 'median', 'q75', 'best5', 'maximum']
    for m in ms:
        mus, hs = [], []
        for k in keys:
            v = np.array([rec[k] for c in corpora for rec in fair.get(f"{c}|{m}", [])], float)
            mu, h = tci(v); mus.append(mu); hs.append(h)
        ax.errorbar(range(len(keys)), mus, yerr=hs, marker='o', ms=2.8, lw=1.0,
                    capsize=1.6, color=MCOL[m], label=m)
    ax.set_xticks(range(len(keys)))
    ax.set_xticklabels(['min', 'worst\nquint.', 'q25', 'median', 'q75', 'best\nquint.', 'max'],
                       fontsize=5.8)
    ax.set_ylabel('balanced accuracy', fontsize=7)
    ax.set_title('(c) Tail of the client distribution', fontsize=8.2, weight='bold')
    ax.legend(frameon=False, fontsize=6.0, loc='lower right')
    fig.tight_layout()
    fig.savefig(FIGD / 'fig5_fairness.png')
    plt.close(fig)
    print('fig5 ok')


# ------------------------------------------------------------------ figure 6
def fig6(cost, cost2, res):
    fig, axes = plt.subplots(1, 2, figsize=(7.4, 2.8))
    ax = axes[0]
    for h, col in zip([64, 128, 256], ['#1565C0', '#C62828', '#2E7D32']):
        for meth, mk, ls in [('FedAvg', 'o', '--'), ('FedAdaW', 's', '-')]:
            xs, ys = [], []
            for k in [10, 20, 50]:
                key = f"StudentDropout|h{h}|K{k}|{meth}"
                if key in cost2:
                    xs.append(k); ys.append(cost2[key]['ms_per_round'])
            if xs:
                ax.plot(xs, ys, marker=mk, ls=ls, ms=3.2, lw=1.1, color=col,
                        label=f"{'FedAdaW' if mk == 's' else 'FedAvg'}, hidden {h}")
    ax.set_xlabel('clients $K$', fontsize=7)
    ax.set_ylabel('ms per communication round', fontsize=7)
    ax.set_xticks([10, 20, 50])
    ax.set_title('(a) Server cost vs clients and model width', fontsize=8.2, weight='bold')
    ax.legend(frameon=False, fontsize=5.4, ncol=2, loc='upper left')

    ax = axes[1]
    ms = [m for m in METHODS if m in cost]
    yy = np.arange(len(ms))[::-1]
    secs = [cost[m]['seconds_10_rounds'] for m in ms]
    mems = [cost[m]['peak_mb'] for m in ms]
    ax.scatter(secs, yy, s=[max(30, min(320, v * 1.6)) for v in mems],
               c=[MCOL[m] for m in ms], alpha=0.75, edgecolor='#333333', lw=0.6, zorder=3)
    for y, m, v, mm_ in zip(yy, ms, secs, mems):
        ax.annotate(f"{v:.0f}s, {mm_:.0f}MB", (v, y), fontsize=5.8,
                    xytext=(7, -2), textcoords='offset points')
    ax.set_yticks(yy); ax.set_yticklabels(ms, fontsize=6.8)
    ax.set_xlabel('seconds for ten communication rounds (log scale)', fontsize=7)
    ax.set_xscale('log')
    ax.set_title('(b) Measured cost per method', fontsize=8.2, weight='bold')
    ax.text(0.02, 0.03, 'marker area ~ peak memory; transmitted volume is\n'
                        'identical for every method at a fixed client count',
            transform=ax.transAxes, fontsize=5.6)
    fig.tight_layout()
    fig.savefig(FIGD / 'fig6_cost.png')
    plt.close(fig)
    print('fig6 ok')


if __name__ == '__main__':
    res, meta = load('results_v10'), load('meta_v10')
    het, abl, diag = load('hetero_v10'), load('ablation_v10'), load('diag_v10')
    fair, cost, cost2 = load('fair_v10'), load('cost_v10'), load('cost2_v10')
    curves = load('curves_v10')
    print('loaded:', {k: len(v) for k, v in [('res', res), ('meta', meta), ('het', het),
                                             ('abl', abl), ('diag', diag), ('fair', fair),
                                             ('cost', cost), ('cost2', cost2),
                                             ('curves', curves)]})
    if res and meta:
        fig1(res, meta); fig2(res, meta, curves, load('variant_v10'))
    if het:
        fig3(het)
    if abl:
        fig4(abl, diag)
    if fair:
        fig5(fair)
    if cost:
        fig6(cost, cost2, res)
    print('figures ->', FIGD)
