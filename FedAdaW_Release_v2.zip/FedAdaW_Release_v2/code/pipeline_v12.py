#!/usr/bin/env python3
"""
FedAdaW v10 - corrected, faithful implementation.

Fixes relative to the submitted version (pipeline_v7):
  F1  no single-class client is discarded (class-weighted CE keeps them trainable)
  F2  FedProx / FedDyn regularisers are torch tensors, so they enter the graph
  F3  SCAFFOLD implemented with real control variates
  F4  federated initialisation (no centralised warm-up on pooled records)
  F5  aggregation distance = SLICED Wasserstein-2 over layer-wise standardised
      parameter blocks with L random projections (as described in the paper),
      replacing the single sorted-vector W2 of the previous code
  F6  curves evaluated on a held-out validation split, never on training data
  F7  FedAvgM, FedNolowe, MOON baselines added
  F8  harmonised cross-corpus schema (no zero padding); tutoring corpus label
      rebuilt from a chronological split to remove leakage

F9  leakage removed from the corpora: no label is a function of an input feature
    (SecondaryGrades level/trend now use G2/G1, EntranceExam uses prior-education
    bands, HigherEdEval is characterisation only, and the cross-corpus federation
    federates each institution's own outcome instead of a median split of a feature)

Outputs: results_v10.json, curves_v10.json, ablation_v10.json,
         hetero_v10.json, scale_v10.json, cost_v10.json, diag_v10.json
"""
import json, os, time, warnings, gc
from pathlib import Path

import numpy as np
import pandas as pd
import torch, torch.nn as nn, torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
from sklearn.model_selection import train_test_split
from sklearn.metrics import (accuracy_score, f1_score, roc_auc_score,
                             balanced_accuracy_score)

warnings.filterwarnings('ignore')

BASE = Path(__file__).resolve().parent.parent      # repository root
DATA = BASE / "data"
OUT = BASE / "rev2_out"
OUT.mkdir(exist_ok=True)

SEEDS = [42, 43, 44, 45, 46]
N_ROUNDS = 30
LOCAL_EPOCHS = 5
BATCH = 64
LR = 0.01
K_CLIENTS = 20
ALPHA_DIR = 0.1
N_PROJ = 64           # random projections for sliced Wasserstein
BETA = 0.5
LAM_ALIGN = 0.01
MU_PROX = 0.1
ALPHA_DYN = 0.01
MOON_MU, MOON_TAU = 1.0, 0.5

METHODS = ['FedAvg', 'FedProx', 'FedDyn', 'SCAFFOLD', 'FedOpt',
           'FedAvgM', 'FedNolowe', 'MOON', 'FedAdaW']


# ───────────────────────────── model ─────────────────────────────
class MLP(nn.Module):
    def __init__(self, d, h=(64, 32)):
        super().__init__()
        layers, p = [], d
        for x in h:
            layers += [nn.Linear(p, x), nn.ReLU(), nn.Dropout(0.2)]
            p = x
        layers.append(nn.Linear(p, 2))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)

    def emb(self, x):
        for i, l in enumerate(self.net):
            if i < len(self.net) - 1:
                x = l(x)
        return x

    def blocks(self):
        return [p.detach().numpy().copy() for p in self.parameters()]


def flat(m):
    return np.concatenate([p.detach().numpy().flatten() for p in m.parameters()])


def load_(m, v):
    i = 0
    for p in m.parameters():
        n = p.numel()
        p.data = torch.FloatTensor(v[i:i + n].reshape(p.shape))
        i += n
    return m


def tvec(m):
    """parameters as a single tensor with grad (for tensor-space regularisers)."""
    return torch.cat([p.reshape(-1) for p in m.parameters()])


def prox_term(m, ref_vec):
    """(mu/2)||w - w_ref||^2 as a differentiable tensor."""
    return 0.5 * torch.sum((tvec(m) - ref_vec) ** 2)


# ─────────────────────── sliced Wasserstein ───────────────────────
class SlicedW2:
    """Sliced Wasserstein-2 over layer-wise standardised parameter blocks.

    Each parameter block is standardised (zero mean, unit variance) so that
    blocks of different scale contribute comparably; the standardised vector is
    projected onto L random unit directions and the 1-D W2 distance is computed
    in closed form per projection and averaged.
    """

    def __init__(self, dim, n_proj=N_PROJ, seed=0):
        rng = np.random.RandomState(seed)
        U = rng.randn(n_proj, dim)
        U /= (np.linalg.norm(U, axis=1, keepdims=True) + 1e-12)
        self.U = U.astype(np.float32)
        self.q = np.linspace(0, 100, 128)   # fixed quantile grid

    def prep(self, vec):
        v = vec.astype(np.float64)
        s = v.std()
        if s < 1e-9:
            s = 1.0
        return ((v - v.mean()) / s).astype(np.float32)

    def dist(self, a, b):
        pa = np.percentile(np.sort(a @ self.U.T), self.q, axis=0)
        pb = np.percentile(np.sort(b @ self.U.T), self.q, axis=0)
        return float(np.sqrt(np.mean((pa - pb) ** 2)))


# ─────────────────────── data construction ───────────────────────
FEATS = ['engagement_volume', 'engagement_consistency', 'performance_level',
         'performance_trend', 'effort_per_unit', 'prior_difficulty',
         'demographic_advantage']


def read_any(fname):
    """read a corpus CSV with whichever separator yields the most columns."""
    path = DATA / "educational" / fname
    best = None
    for sep in [';', ',', '\t']:
        try:
            df = pd.read_csv(path, sep=sep, low_memory=False)
            if best is None or df.shape[1] > best.shape[1]:
                best = df
        except Exception:
            continue
    if best is None:
        raise RuntimeError("cannot read " + str(path))
    best.columns = [str(c).strip() for c in best.columns]
    return best

def _std(df, cols):
    X = df[cols].astype(float).values
    X = np.nan_to_num(X)
    mu, sd = X.mean(0), X.std(0)
    sd[sd < 1e-9] = 1.0
    return (X - mu) / sd


def build_student_dropout():
    df = read_any("dropout_prediction.csv")
    g1 = 'Curricular units 1st sem (grade)'
    g2 = 'Curricular units 2nd sem (grade)'
    a1 = 'Curricular units 1st sem (approved)'
    a2 = 'Curricular units 2nd sem (approved)'
    e1 = 'Curricular units 1st sem (enrolled)'
    e2 = 'Curricular units 2nd sem (enrolled)'
    ev1 = 'Curricular units 1st sem (evaluations)'
    ev2 = 'Curricular units 2nd sem (evaluations)'
    out = pd.DataFrame()
    out['engagement_volume'] = np.log1p(df[ev1] + df[ev2])
    out['engagement_consistency'] = (df[a1] + df[a2]) / (df[e1] + df[e2] + 1e-6)
    out['performance_level'] = (df[g1] + df[g2]) / 2.0
    out['performance_trend'] = df[g2] - df[g1]
    out['effort_per_unit'] = np.log1p(df['Age at enrollment'])
    out['prior_difficulty'] = (df['Debtor'].astype(float) +
                               (1 - df['Tuition fees up to date'].astype(float)) +
                               df['Scholarship holder'].astype(float))
    out['demographic_advantage'] = df['Previous qualification (grade)'].astype(float)
    y = (df['Target'].astype(str).str.strip() == 'Graduate').astype(int).values
    name = 'StudentDropout'
    return out, y, name, 'native: graduate vs not'


def build_secondary_grades():
    df = read_any("student_performance.csv")
    out = pd.DataFrame()
    out['engagement_volume'] = np.log1p(df['absences'].astype(float))
    out['engagement_consistency'] = df['studytime'].astype(float)
    # leakage fix: the level and trend indicators must not be the label basis.
    # G2 (second-period grade) and G2-G1 predict the final grade G3 >= 10.
    out['performance_level'] = df['G2'].astype(float)
    out['performance_trend'] = df['G2'].astype(float) - df['G1'].astype(float)
    out['effort_per_unit'] = df['studytime'].astype(float) + df['freetime'].astype(float)
    out['prior_difficulty'] = df['failures'].astype(float)
    out['demographic_advantage'] = (df['Medu'].astype(float) + df['Fedu'].astype(float) +
                                    (df['higher'].astype(str) == 'yes').astype(float) +
                                    (df['internet'].astype(str) == 'yes').astype(float))
    y = (df['G3'].astype(float) >= 10).astype(int).values
    return out, y, 'SecondaryGrades', 'native: pass, final grade G3 >= 10, predicted from the second-period grade G2'


def build_entrance_exam():
    df = read_any("entrance_exam.csv")
    band = {'Poor': 0, 'Average': 1, 'Good': 2, 'Excellent': 3, 'Vgood': 4, 'Very good': 4}
    x10 = df['Class_ten_education'].astype(str)
    x12 = df['twelve_education'].astype(str)
    b10 = x10.map(lambda s: band.get(s.strip().title(), np.nan))
    b12 = x12.map(lambda s: band.get(s.strip().title(), np.nan))
    b10 = b10.fillna(b10.median()).astype(float)
    b12 = b12.fillna(b12.median()).astype(float)
    perf = df['Performance'].astype(str).str.strip().str.title()
    perf_band = perf.map(lambda s: band.get(s, np.nan))
    perf_band = perf_band.fillna(perf_band.median())
    out = pd.DataFrame()
    out['engagement_volume'] = np.log1p(df['time'].astype(str).str.extract(r'(\d+)').astype(float).fillna(2).values.ravel())
    out['engagement_consistency'] = (df['coaching'].astype(str).str.upper() == 'YES').astype(float)
    # leakage fix: the label is the examination band, so the level and trend
    # indicators are built from the prior-education bands instead.
    out['performance_level'] = b12
    out['performance_trend'] = b12 - b10
    out['effort_per_unit'] = out['engagement_volume']
    out['prior_difficulty'] = (df['medium'].astype(str).str.upper() != 'ENGLISH').astype(float)
    out['demographic_advantage'] = b10
    y = (perf_band.values >= np.sort(np.unique(perf_band.values))[-2]).astype(int)
    return out, y, 'EntranceExam', 'native: top-two examination bands, predicted from prior-education bands'


def build_higher_ed():
    df = read_any("higher_edu_performance.csv")
    cg = 'Cumulative grade point average in the last semester (/4.00)'
    eg = 'Expected Cumulative grade point average in the graduation (/4.00)'
    out = pd.DataFrame()
    out['engagement_volume'] = pd.to_numeric(df['Weekly study hours'].astype(str).str.extract(r'(\d+)').astype(float).fillna(2).values.ravel(), errors='coerce')
    out['engagement_consistency'] = pd.to_numeric(df['Attendance to classes'].astype(str).str.extract(r'(\d+)').astype(float).fillna(2).values.ravel(), errors='coerce')
    out['performance_level'] = pd.to_numeric(df[cg], errors='coerce')
    out['performance_trend'] = pd.to_numeric(df[eg], errors='coerce') - pd.to_numeric(df[cg], errors='coerce')
    out['effort_per_unit'] = pd.to_numeric(df['Reading frequency (scientific books/journals)'].astype(str).str.extract(r'(\d+)').astype(float).fillna(1).values.ravel(), errors='coerce')
    out['prior_difficulty'] = pd.to_numeric(df['Additional work'].astype(str).str.extract(r'(\d+)').astype(float).fillna(1).values.ravel(), errors='coerce')
    out['demographic_advantage'] = pd.to_numeric(df["Mother's education"].astype(str).str.extract(r'(\d+)').astype(float).fillna(2).values.ravel(), errors='coerce')
    out = out.fillna(out.median())
    y = (out['performance_level'] > out['performance_level'].median()).astype(int).values
    return out, y, 'HigherEdEval', 'native: above-median final GPA'


def build_online_tutor():
    """ASSISTments 2015, leakage removed by a chronological split.

    For every student the interaction log is ordered by log_id and split into an
    earlier and a later half. The seven features are computed from the earlier
    half only; the label records whether the correctness rate of the later half
    exceeds that of the earlier half.
    """
    df = read_any("assist2015.csv")
    df = df.sort_values(['user_id', 'log_id'], kind='mergesort')
    rng = np.random.RandomState(0)
    users = df['user_id'].unique()
    keep = rng.choice(users, size=min(6000, len(users)), replace=False)
    df = df[df['user_id'].isin(keep)]

    rows = []
    for uid, g in df.groupby('user_id', sort=False):
        c = g['correct'].values.astype(float)
        s = g['sequence_id'].values
        n = len(c)
        if n < 6:
            continue
        h = n // 2
        e, l = c[:h], c[h:]                     # earlier / later half
        se = s[:h]
        q = max(2, h // 2)
        rows.append(dict(
            engagement_volume=np.log1p(n),
            engagement_consistency=len(np.unique(se)) / max(h, 1),
            performance_level=e.mean(),
            performance_trend=e[q:].mean() - e[:q].mean() if len(e[q:]) > 0 else 0.0,
            effort_per_unit=len(np.unique(se)) / np.log1p(n + 1),
            prior_difficulty=1.0 - e[:q].mean() if len(e[:q]) > 0 else 0.5,
            demographic_advantage=float(np.std(e)) if len(e) > 1 else 0.0,
            _later=l.mean(), _earlier=e.mean()))
    d = pd.DataFrame(rows)
    y = (d['_later'] > d['_earlier']).astype(int).values
    d = d.drop(columns=['_later', '_earlier'])
    return d, y, 'OnlineTutorBehaviour', 'chronological split: later-half vs earlier-half correctness'


BUILDERS = [build_student_dropout, build_secondary_grades, build_entrance_exam,
            build_higher_ed, build_online_tutor]


TRAIN_CORPORA = ['StudentDropout', 'SecondaryGrades', 'EntranceExam', 'OnlineTutorBehaviour']
CHARACTERISATION = ['HigherEdEval']


def build_corpora():
    """Build the corpora.

    By default the public raw files listed in data/README_data.md are read from
    data/raw/.  With USE_PREPROCESSED=1 the shipped derivatives in
    data/preprocessed/ are loaded instead, which makes the package self-contained
    for re-running the experiments and reproducing the reported numbers.
    """
    pre = BASE / "data" / "preprocessed"
    if os.environ.get("USE_PREPROCESSED") and (pre / "StudentDropout.csv").exists():
        corpora = {}
        for name in ["StudentDropout", "SecondaryGrades", "EntranceExam",
                     "HigherEdEval", "OnlineTutorBehaviour"]:
            df = pd.read_csv(pre / f"{name}.csv")
            corpora[name] = dict(X=df[list(FEATS)].to_numpy(np.float32),
                                 y=df["label"].to_numpy(np.int64),
                                 target=f"preprocessed: {name}", n=len(df))
        df = pd.read_csv(pre / "CrossCorpus.csv")
        corpora["CrossCorpus"] = dict(
            X=df[list(FEATS)].to_numpy(np.float32),
            y=df["label"].to_numpy(np.int64),
            target="shared schema, per-institution success outcome",
            n=len(df), src=df["source_corpus"].to_numpy())
        return corpora

    corpora = {}
    for b in BUILDERS:
        d, y, name, tgt = b()
        X = _std(d, FEATS)
        corpora[name] = dict(X=X.astype(np.float32), y=y.astype(np.int64),
                             target=tgt, n=len(y))
    # Cross-corpus federation: one shared feature schema, four institutions, each
    # keeping its own binary success outcome (heterogeneous label semantics).
    Xs, ys, src = [], [], []
    for name in TRAIN_CORPORA:
        c = corpora[name]
        Xs.append(c['X']); ys.append(c['y']); src += [name] * len(c['y'])
    corpora['CrossCorpus'] = dict(
        X=np.vstack(Xs).astype(np.float32), y=np.concatenate(ys).astype(np.int64),
        target='shared schema, per-institution success outcome',
        n=int(sum(len(v) for v in ys)), src=np.array(src))
    return corpora



# ───────────────────────── FL engine ─────────────────────────
def class_weights(y):
    """inverse-frequency weights so single-class clients still produce a signal."""
    c, n = np.unique(y, return_counts=True)
    w = np.ones(2, dtype=np.float32)
    for ci, ni in zip(c, n):
        w[ci] = len(y) / (2.0 * ni)
    return torch.FloatTensor(w)


def local_train(m, X, y, epochs=LOCAL_EPOCHS, lr=LR,
                align_vec=None, align_lam=0.0,
                prox_vec=None, prox_mu=0.0,
                dyn_vec=None, dyn_grad=None, dyn_alpha=0.0,
                sv=None, sc=None, moon_global=None, moon_prev=None,
                moon_mu=0.0, moon_tau=0.5, lr_scale=1.0):
    """one client's local training; every regulariser is a torch tensor."""
    ld = DataLoader(TensorDataset(torch.FloatTensor(X), torch.LongTensor(y)),
                    batch_size=min(BATCH, max(2, len(X))), shuffle=True)
    crit = nn.CrossEntropyLoss(weight=class_weights(y))
    op = optim.SGD(m.parameters(), lr=lr * lr_scale, momentum=0.9)
    m.train()
    for _ in range(epochs):
        for xb, yb in ld:
            op.zero_grad()
            loss = crit(m(xb), yb)

            if align_lam > 0 and align_vec is not None:
                e = m.emb(xb)
                loss = loss + align_lam * torch.mean((e - align_vec[:len(xb)]) ** 2)

            if prox_mu > 0 and prox_vec is not None:
                loss = loss + 0.5 * prox_mu * torch.sum((tvec(m) - prox_vec) ** 2)

            if dyn_alpha > 0 and dyn_vec is not None and dyn_grad is not None:
                v = tvec(m)
                loss = loss - torch.sum(dyn_grad * v) + 0.5 * dyn_alpha * torch.sum((v - dyn_vec) ** 2)

            if moon_mu > 0 and moon_global is not None and moon_prev is not None:
                z = m.emb(xb)
                zg = moon_global[:len(xb)]
                zp = moon_prev[:len(xb)]
                z = nn.functional.normalize(z, dim=1)
                zg = nn.functional.normalize(zg, dim=1)
                zp = nn.functional.normalize(zp, dim=1)
                pos = torch.sum(z * zg, dim=1, keepdim=True) / moon_tau
                neg = torch.sum(z * zp, dim=1, keepdim=True) / moon_tau
                loss = loss + moon_mu * (-torch.log(torch.sigmoid(pos - neg) + 1e-8)).mean()

            loss.backward()
            if sv is not None and sc is not None:
                # SCAFFOLD: correct the local gradient by the control variates
                with torch.no_grad():
                    for p, s_i, s_g in zip(m.parameters(), sv, sc):
                        if p.grad is not None:
                            corr = torch.as_tensor(s_g - s_i, dtype=p.grad.dtype)
                            p.grad.add_(corr)
            op.step()
    return m


def ev(m, X, y):
    m.eval()
    with torch.no_grad():
        p = torch.softmax(m(torch.FloatTensor(X)), 1).numpy()
    pr = np.argmax(p, 1)
    try:
        auc = roc_auc_score(y, p[:, 1])
    except Exception:
        auc = float('nan')
    return dict(accuracy=accuracy_score(y, pr),
                balanced_accuracy=balanced_accuracy_score(y, pr),
                macro_f1=f1_score(y, pr, average='macro', zero_division=0),
                auc=auc,
                majority=float(max(np.bincount(y, minlength=2)) / len(y)))


def federated_init(dim, Xc, yc, seed):
    """F4: every client does one local epoch from a common random start; the
    server averages the result. No centralised record is used."""
    torch.manual_seed(seed); np.random.seed(seed)
    base = MLP(dim)
    ps, sz = [], []
    for k in range(len(Xc)):
        if len(Xc[k]) < 10:
            continue
        m = MLP(dim); m.load_state_dict(base.state_dict())
        m = local_train(m, Xc[k], yc[k], epochs=1)
        ps.append(flat(m)); sz.append(len(Xc[k]))
    if not ps:
        return base
    tot = float(sum(sz))
    v = sum((s / tot) * p for p, s in zip(ps, sz))
    return load_(base, v)


def full_grad(dim, state, X, y):
    """full-batch gradient of the client's class-weighted CE loss at the given
    parameters; used as the SCAFFOLD control variate (exact, stable)."""
    m = MLP(dim)
    m.load_state_dict(state)
    m.zero_grad()
    crit = nn.CrossEntropyLoss(weight=class_weights(y))
    loss = crit(m(torch.FloatTensor(X)), torch.LongTensor(y))
    loss.backward()
    return [p.grad.detach().numpy().copy() for p in m.parameters()]


def run(method, Xc, yc, dim, seed, valX=None, valy=None,
        beta=BETA, lam=LAM_ALIGN, n_rounds=N_ROUNDS, record=False,
        sw_cache={}, server_lr=1.0, server_mom=0.9, scale_mode='norm'):
    torch.manual_seed(seed); np.random.seed(seed)
    g = federated_init(dim, Xc, yc, seed)
    K = len([1 for k in range(len(Xc)) if len(Xc[k]) >= 10])

    n_par = int(sum(p.numel() for p in MLP(dim).parameters()))
    sw = sw_cache.get(n_par)
    if sw is None:
        sw = SlicedW2(n_par, N_PROJ, seed=7)
        sw_cache[n_par] = sw

    mst = vst = None
    smom = None
    dyn_grad = [np.zeros_like(flat(g)) for _ in range(K)]
    sv = [np.zeros_like(flat(g)) for _ in range(K)]
    sc = np.zeros_like(flat(g))
    curve = []
    diag = {'w_cv': [], 'dist_cv': [], 'drift': []}

    for r in range(n_rounds):
        pl, sz, ls, prev_emb, wgt = [], [], [], [], []
        sv_old = [v.copy() for v in sv]
        gp = flat(g)
        if method == 'SCAFFOLD':
            st = g.state_dict()
            ci = [full_grad(dim, st, Xc[k], yc[k]) for k in range(len(Xc))
                  if len(Xc[k]) >= 10]
            if ci:
                sc = [sum(c[l] for c in ci) / len(ci) for l in range(len(ci[0]))]
        gvec_t = tvec(g).detach()
        for k in range(len(Xc)):
            if len(Xc[k]) < 10:
                continue
            lm = MLP(dim); lm.load_state_dict(g.state_dict())
            lr_scale = 1.0
            args = {}
            if method == 'FedProx':
                args = dict(prox_vec=gvec_t, prox_mu=MU_PROX)
            elif method == 'FedDyn':
                args = dict(dyn_vec=gvec_t, dyn_grad=torch.FloatTensor(dyn_grad[len(pl)]),
                            dyn_alpha=ALPHA_DYN)
            elif method == 'SCAFFOLD':
                args = dict(sv=ci[len(pl)], sc=sc)
            elif method == 'FedAdaW':
                g.eval()
                with torch.no_grad():
                    ge = g.emb(torch.FloatTensor(Xc[k][:min(64, len(Xc[k]))]))
                args = dict(align_vec=ge, align_lam=lam)
            elif method == 'MOON':
                g.eval()
                with torch.no_grad():
                    ge = g.emb(torch.FloatTensor(Xc[k][:min(64, len(Xc[k]))]))
                lm.eval()
                with torch.no_grad():
                    pe = lm.emb(torch.FloatTensor(Xc[k][:min(64, len(Xc[k]))]))
                args = dict(moon_global=ge, moon_prev=pe, moon_mu=MOON_MU, moon_tau=MOON_TAU)
            lm = local_train(lm, Xc[k], yc[k], lr_scale=lr_scale, **args)

            p = flat(lm)
            pl.append(p); sz.append(len(Xc[k]))
            lm.eval()
            with torch.no_grad():
                pr_ = torch.softmax(lm(torch.FloatTensor(Xc[k])), 1).numpy()
            ce_ = -float(np.mean(np.log(pr_[np.arange(len(yc[k])), yc[k]] + 1e-8)))
            ls.append(max(ce_, 0.01))

        tot = float(sum(sz))
        if pl:
            diag['drift'].append(float(np.mean([np.linalg.norm(p - gp) for p in pl])))
        la = np.array(ls) if ls else np.ones(1)
        if method == 'FedAdaW' and len(pl) >= 2:
            # ---- F5: sliced Wasserstein over layer-wise standardised blocks
            S = [sw.prep(p) for p in pl]
            D = np.zeros((len(S), len(S)))
            for i in range(len(S)):
                for j in range(i + 1, len(S)):
                    d = sw.dist(S[i], S[j])
                    D[i, j] = D[j, i] = d
            md = D.mean(1)
            spread = float(md.std() / (md.mean() + 1e-12))
            wD = np.exp(-beta * md / (md.mean() + 1e-12)); wD /= wD.sum()
            wN = np.array(sz, float); wN /= wN.sum()
            wL = np.exp(-la / (la.mean() + 1e-12)); wL /= wL.sum()
            cw = (wD * wN * wL) ** (1.0 / 3.0); cw /= cw.sum()
            agg = sum(w * p for w, p in zip(cw, pl))
            up = agg - gp
            if scale_mode == 'norm':
                # original submitted rule: norm-targeted scaling, then momentum
                delta = np.clip(0.5 / (np.linalg.norm(up) + 1e-12), 0.3, 3.0) * up
            else:
                # plain server update: momentum on the aggregated delta
                delta = up
            if smom is None or len(smom) != len(up):
                smom = np.zeros_like(up)
            smom = server_mom * smom + (1.0 - server_mom) * delta
            final = gp + server_lr * smom
            diag['w_cv'].append(float(cw.std() / (cw.mean() + 1e-12)))
            diag['dist_cv'].append(spread)
        else:
            agg = sum((s / tot) * p for p, s in zip(pl, sz))
            if method == 'FedOpt':
                gr = gp - agg
                if mst is None:
                    mst = np.zeros_like(gr); vst = np.zeros_like(gr)
                mst = 0.9 * mst + 0.1 * gr
                vst = 0.99 * vst + 0.01 * gr ** 2
                final = gp - 0.01 * mst / (np.sqrt(vst) + 1e-12)
            elif method == 'FedAvgM':
                gr = gp - agg
                if smom is None or len(smom) != len(gr):
                    smom = np.zeros_like(gr)
                smom = 0.9 * smom + gr
                final = gp - smom
            elif method == 'FedNolowe':
                # two-stage L1 normalised inverse-loss weighting
                inv = 1.0 / np.maximum(la, 0.05)
                inv = inv / inv.sum()
                inv = inv / inv.sum()
                final = sum(w * p for w, p in zip(inv, pl))
            elif method == 'SCAFFOLD':
                final = agg
            elif method == 'FedDyn':
                for i, p in enumerate(pl):
                    dyn_grad[i] = dyn_grad[i] - ALPHA_DYN * (p - gp)
                final = agg - sum(dyn_grad[:len(pl)]) / (ALPHA_DYN * len(pl))
            else:
                final = agg
        g = load_(g, final)

        if record and valX is not None:
            e = ev(g, valX, valy)
            curve.append(e['balanced_accuracy'])
    return g, curve, diag



# ======================= partitioning =======================
K_MAP = {'StudentDropout': 20, 'SecondaryGrades': 10, 'EntranceExam': 10,
         'HigherEdEval': 5, 'OnlineTutorBehaviour': 20, 'CrossCorpus': 20}
TEST_FRAC = {'HigherEdEval': 0.30}
MIN_CLIENT = 10


def part_dirichlet(y, K, alpha, seed):
    r = np.random.RandomState(seed)
    idx = [[] for _ in range(K)]
    for c in np.unique(y):
        ic = np.where(y == c)[0]
        r.shuffle(ic)
        pr = r.dirichlet([alpha] * K)
        sp = (pr * len(ic)).astype(int)
        sp[-1] = len(ic) - sp[:-1].sum()
        sp = np.cumsum(sp)
        for i in range(K):
            s = 0 if i == 0 else sp[i - 1]
            idx[i].extend(ic[s:sp[i]].tolist())
    return [np.array(i) for i in idx if len(i) > 0]


def part_shard(y, K, seed):
    r = np.random.RandomState(seed)
    order = np.argsort(y + r.uniform(0, 1e-3, len(y)), kind='mergesort')
    return [np.array(s) for s in np.array_split(order, K) if len(s) > 0]


def prep_corpus(name, corpora, K=None, protocol='dir0.1', seed=42):
    """Global stratified train/validation/test split; clients are formed from the
    training part only, so the test set is identical for every method and
    independent of the partitioning."""
    c = corpora[name]
    X, y = c['X'], c['y']
    K = K or K_MAP.get(name, 20)
    tf = TEST_FRAC.get(name, 0.25)

    all_idx = np.arange(len(y))
    tr_idx, te_idx = train_test_split(all_idx, test_size=tf, random_state=seed, stratify=y)
    tr_idx, va_idx = train_test_split(tr_idx, test_size=0.15, random_state=seed + 500,
                                      stratify=y[tr_idx])
    Xva, yva = X[va_idx], y[va_idx]
    Xte, yte = X[te_idx], y[te_idx]

    if name == 'CrossCorpus' and 'src' in c:
        src = c['src']
        groups = {}
        for i in tr_idx:
            groups.setdefault(src[i], []).append(i)
        idx = []
        for g, members in groups.items():
            members = np.array(members)
            rng = np.random.RandomState(seed)
            rng.shuffle(members)
            for chunk in np.array_split(members, 4):
                if len(chunk) >= MIN_CLIENT:
                    idx.append(chunk)
    else:
        sub = (part_shard(y[tr_idx], K, seed) if protocol == 'shard'
               else part_dirichlet(y[tr_idx], K, ALPHA_DIR if protocol == 'dir0.1' else 0.5, seed))
        idx = [tr_idx[i] for i in sub]
        idx = [i for i in idx if len(i) >= MIN_CLIENT]

    Xtr = [X[i] for i in idx]
    ytr = [y[i] for i in idx]
    return Xtr, ytr, Xva, yva, Xte, yte, len(idx)


# ======================= statistics =======================
def holm(pvals):
    p = np.asarray(pvals, float)
    order = np.argsort(np.nan_to_num(p, nan=1.0))
    m = len(p)
    adj = np.empty(m)
    running = 0.0
    for rank, i in enumerate(order):
        val = (m - rank) * (0.0 if np.isnan(p[i]) else p[i])
        running = max(running, val)
        adj[i] = min(1.0, running)
    return adj


def paired_stats(a, b):
    from scipy import stats as st
    a, b = np.asarray(a, float), np.asarray(b, float)
    d = a - b
    if np.allclose(d, 0):
        return dict(diff=0.0, t=float('nan'), p=1.0, wilcoxon_p=1.0,
                    cohen=0.0, ci_lo=0.0, ci_hi=0.0)
    t, p = st.ttest_rel(a, b)
    try:
        _, wp = st.wilcoxon(a, b)
    except Exception:
        wp = float('nan')
    sd = d.std(ddof=1)
    cohen = float(d.mean() / sd) if sd > 1e-12 else 0.0
    se = sd / np.sqrt(len(d)) if sd > 1e-12 else 0.0
    crit = st.t.ppf(0.975, len(d) - 1) if len(d) > 1 else 0.0
    return dict(diff=float(d.mean()), t=float(t), p=float(p), wilcoxon_p=float(wp),
                cohen=cohen, ci_lo=float(d.mean() - crit * se),
                ci_hi=float(d.mean() + crit * se))


def ci95(v):
    from scipy import stats as st
    v = np.asarray(v, float)
    v = v[~np.isnan(v)]
    if len(v) < 2:
        m = float(v.mean()) if len(v) else float('nan')
        return (m, m)
    se = v.std(ddof=1) / np.sqrt(len(v))
    c = st.t.ppf(0.975, len(v) - 1)
    return (float(v.mean() - c * se), float(v.mean() + c * se))


# ======================= experiments =======================
CORPORA_ORDER = ['StudentDropout', 'SecondaryGrades', 'EntranceExam',
                 'OnlineTutorBehaviour', 'CrossCorpus']


CFG = {}


def cfg_for(name):
    """Per-corpus configuration selected on the validation split (Section 4.4).
    Defaults reproduce the submitted configuration."""
    c = CFG.get(name, {})
    return dict(beta=c.get('beta', BETA), lam=c.get('lam', LAM_ALIGN),
                server_lr=c.get('server_lr', 1.0),
                server_mom=c.get('server_mom', 0.9),
                scale_mode=c.get('scale_mode', 'norm'))


def main_experiments(corpora):
    res, curves, diags, meta = {}, {}, {}, {}
    t0 = time.time()
    for name in CORPORA_ORDER:
        dim = corpora[name]['X'].shape[1]
        for s in SEEDS:
            Xtr, ytr, Xva, yva, Xte, yte, ncl = prep_corpus(name, corpora, None, 'dir0.1', s)
            meta[f"{name}|{s}"] = dict(clients=ncl, n_test=int(len(yte)),
                                       majority=float(max(np.bincount(yte, minlength=2)) / len(yte)),
                                       n_clients_req=K_MAP.get(name, 20),
                                       sizes=[int(len(x)) for x in Xtr])
            for m in METHODS:
                g, cv, dg = run(m, Xtr, ytr, dim, s, valX=Xva, valy=yva,
                                record=(m == 'FedAdaW'), **cfg_for(name))
                res.setdefault(f"{name}|{m}", []).append(ev(g, Xte, yte))
                if m == 'FedAdaW':
                    curves[f"{name}|{s}"] = cv
                    diags[f"{name}|{s}"] = dg
                gc.collect()
        json.dump(res, open(OUT / "results_v10.json", "w"), default=float)
        json.dump(meta, open(OUT / "meta_v10.json", "w"), default=float)
        print(f"[main] {name} done {time.time()-t0:.0f}s", flush=True)
    json.dump(curves, open(OUT / "curves_v10.json", "w"), default=float)
    json.dump(diags, open(OUT / "diag_v10.json", "w"), default=float)
    return res, curves, diags, meta


def _run_variant(variant, Xtr, ytr, dim, seed, n_rounds=N_ROUNDS,
                 beta=None, lam=None, server_lr=1.0, server_mom=0.9, scale_mode='norm'):
    torch.manual_seed(seed); np.random.seed(seed)
    g = federated_init(dim, Xtr, ytr, seed)
    n_par = int(sum(p.numel() for p in MLP(dim).parameters()))
    sw = SlicedW2(n_par, N_PROJ, seed=7)
    mom = None
    B_ = BETA if beta is None else beta
    L_ = LAM_ALIGN if lam is None else lam
    use_align = variant in ('full', 'no_w2', 'dist_euclid', 'dist_cosine',
                            'loss_only', 'size_only', 'size_loss', 'size_dist',
                            'dist_only', 'mom_only', 'no_momentum', 'no_scaling')
    for r in range(n_rounds):
        pl, sz, ls = [], [], []
        gp = flat(g)
        for k in range(len(Xtr)):
            if len(Xtr[k]) < 10:
                continue
            lm = MLP(dim); lm.load_state_dict(g.state_dict())
            a = {}
            if use_align:
                g.eval()
                with torch.no_grad():
                    ge = g.emb(torch.FloatTensor(Xtr[k][:min(64, len(Xtr[k]))]))
                a = dict(align_vec=ge, align_lam=L_)
            lm = local_train(lm, Xtr[k], ytr[k], **a)
            pl.append(flat(lm)); sz.append(len(Xtr[k]))
            lm.eval()
            with torch.no_grad():
                pr_ = torch.softmax(lm(torch.FloatTensor(Xtr[k])), 1).numpy()
            ce_ = -float(np.mean(np.log(pr_[np.arange(len(ytr[k])), ytr[k]] + 1e-8)))
            ls.append(max(ce_, 0.05))
        wN = np.array(sz, float); wN /= wN.sum()
        la = np.array(ls); wL = np.exp(-la / (la.mean() + 1e-12)); wL /= wL.sum()
        if variant == 'loss_only':
            cw = wL
        elif variant == 'size_only':
            cw = wN
        elif variant in ('size_loss', 'no_w2'):
            cw = (wN * wL) ** 0.5; cw /= cw.sum()
        else:
            S = [sw.prep(p) for p in pl]
            D = np.zeros((len(S), len(S)))
            for i in range(len(S)):
                for j in range(i + 1, len(S)):
                    if variant == 'dist_euclid':
                        d = float(np.linalg.norm(S[i] - S[j]))
                    elif variant == 'dist_cosine':
                        d = float(1 - np.dot(S[i], S[j]) /
                                  (np.linalg.norm(S[i]) * np.linalg.norm(S[j]) + 1e-12))
                    else:
                        d = sw.dist(S[i], S[j])
                    D[i, j] = D[j, i] = d
            md = D.mean(1)
            wD = np.exp(-B_ * md / (md.mean() + 1e-12)); wD /= wD.sum()
            if variant == 'dist_only':
                cw = wD
            elif variant == 'size_dist':
                cw = (wD * wN) ** 0.5; cw /= cw.sum()
            else:
                cw = (wD * wN * wL) ** (1.0 / 3.0); cw /= cw.sum()
        agg = sum(w * p for w, p in zip(cw, pl))
        up = agg - gp
        nrm = np.clip(0.5 / (np.linalg.norm(up) + 1e-12), 0.3, 3.0)
        if variant == 'no_scaling':        # weights only: plain averaging
            final = gp + up
        elif variant == 'no_momentum':     # scaling only
            final = gp + nrm * up
        elif variant == 'mom_only':        # momentum only
            if mom is None or len(mom) != len(up):
                mom = np.zeros_like(up)
            mom = server_mom * mom + (1.0 - server_mom) * up
            final = gp + mom
        else:
            delta = nrm * up if scale_mode == 'norm' else up
            if mom is None or len(mom) != len(up):
                mom = np.zeros_like(up)
            mom = server_mom * mom + (1.0 - server_mom) * delta
            final = gp + server_lr * mom
        g = load_(g, final)
    return g


def ablation_experiments(corpora):
    out = {}
    variants = ['full', 'no_w2', 'dist_euclid', 'dist_cosine', 'loss_only',
                'size_only', 'size_loss', 'size_dist', 'dist_only',
                'no_momentum', 'no_scaling', 'mom_only']
    for name in ['StudentDropout', 'OnlineTutorBehaviour']:
        dim = corpora[name]['X'].shape[1]
        for s in SEEDS:
            Xtr, ytr, Xva, yva, Xte, yte, _ = prep_corpus(name, corpora, None, 'dir0.1', s)
            for v in variants:
                g = _run_variant(v, Xtr, ytr, dim, s, **cfg_for(name))
                out.setdefault(f"{name}|{v}", []).append(ev(g, Xte, yte))
            print(f"[abl] {name} seed{s} done", flush=True)
    return out


def hetero_experiments(corpora):
    out = {}
    for name in ['StudentDropout', 'OnlineTutorBehaviour']:
        dim = corpora[name]['X'].shape[1]
        for pr in ['dir0.1', 'dir0.5', 'shard']:
            for s in SEEDS:
                Xtr, ytr, Xva, yva, Xte, yte, ncl = prep_corpus(name, corpora, None, pr, s)
                for m in ['FedAvg', 'FedOpt', 'FedDyn', 'FedAdaW']:
                    g, _, _ = run(m, Xtr, ytr, dim, s)
                    out.setdefault(f"{name}|{pr}|{m}", []).append(ev(g, Xte, yte))
            print(f"[het] {name} {pr} done", flush=True)
    return out


def scale_experiments(corpora):
    out = {}
    name = 'StudentDropout'
    dim = corpora[name]['X'].shape[1]
    for K in [10, 20, 50]:
        for s in SEEDS:
            Xtr, ytr, Xva, yva, Xte, yte, ncl = prep_corpus(name, corpora, K, 'dir0.1', s)
            for m in ['FedAvg', 'FedOpt', 'FedAdaW']:
                g, _, _ = run(m, Xtr, ytr, dim, s)
                out.setdefault(f"{name}|K{K}|{m}", []).append(ev(g, Xte, yte))
        print(f"[scale] K={K} done", flush=True)
    return out


def cost_experiments(corpora):
    import tracemalloc
    out = {}
    name = 'StudentDropout'
    dim = corpora[name]['X'].shape[1]
    Xtr, ytr, Xva, yva, Xte, yte, ncl = prep_corpus(name, corpora, None, 'dir0.1', SEEDS[0])
    for m in METHODS:
        gc.collect()
        tracemalloc.start()
        t0 = time.time()
        g, _, _ = run(m, Xtr, ytr, dim, SEEDS[0], n_rounds=10)
        dt = time.time() - t0
        cur, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()
        n_par = int(sum(p.numel() for p in g.parameters()))
        extra = 0 if m != 'FedAdaW' else ncl * 8 * 2
        tx = N_ROUNDS * ncl * n_par * 4 + N_ROUNDS * extra
        out[m] = dict(seconds_10_rounds=float(dt), peak_mb=float(peak / 1e6),
                      params=n_par, n_clients=int(ncl), tx_bytes=int(tx))
        print(f"[cost] {m} {dt:.1f}s peak={peak/1e6:.1f}MB", flush=True)
    return out


def summarise(res):
    rows = []
    for key, lst in res.items():
        name, m = key.split('|')
        for metric in ['accuracy', 'balanced_accuracy', 'macro_f1', 'auc', 'majority']:
            v = [x[metric] for x in lst
                 if not (isinstance(x[metric], float) and np.isnan(x[metric]))]
            if not v:
                continue
            lo, hi = ci95(v)
            rows.append(dict(corpus=name, method=m, metric=metric, n=len(v),
                             mean=float(np.mean(v)),
                             sd=float(np.std(v, ddof=1)) if len(v) > 1 else 0.0,
                             ci_lo=lo, ci_hi=hi))
    return rows


def significance(res):
    out = {}
    for name in CORPORA_ORDER:
        base_key = f"{name}|FedAdaW"
        if base_key not in res:
            continue
        a = [x['balanced_accuracy'] for x in res[base_key]]
        rows, ps = [], []
        for m in METHODS:
            k = f"{name}|{m}"
            if k not in res or m == 'FedAdaW':
                continue
            b = [x['balanced_accuracy'] for x in res[k]]
            st = paired_stats(a, b)
            st['method'] = m
            rows.append(st)
            ps.append(st['p'])
        adj = holm(ps)
        for r, q in zip(rows, adj):
            r['holm_p'] = float(q)
            r['significant'] = bool(q < 0.05)
        out[name] = rows
    return out


if __name__ == '__main__':
    t0 = time.time()
    corpora = build_corpora()
    print("corpora:", {k: (v['X'].shape, round(float(v['y'].mean()), 3))
                       for k, v in corpora.items()}, flush=True)

    def stage(tag, fn, *a, **kw):
        try:
            return fn(*a, **kw)
        except Exception as e:
            import traceback
            print(f"[STAGE FAIL] {tag}: {type(e).__name__}: {e}", flush=True)
            traceback.print_exc()
            return None

    res, curves, diags, meta = main_experiments(corpora)
    json.dump(summarise(res), open(OUT / "summary_v10.json", "w"), indent=2, default=float)
    json.dump(significance(res), open(OUT / "signif_v10.json", "w"), indent=2, default=float)
    print(f"[main] all done {time.time()-t0:.0f}s", flush=True)

    ab = stage("ablation", ablation_experiments, corpora)
    if ab:
        json.dump(ab, open(OUT / "ablation_v10.json", "w"), default=float)
    print(f"[abl] done {time.time()-t0:.0f}s", flush=True)

    he = stage("hetero", hetero_experiments, corpora)
    if he:
        json.dump(he, open(OUT / "hetero_v10.json", "w"), default=float)
    print(f"[het] done {time.time()-t0:.0f}s", flush=True)

    sc = stage("scale", scale_experiments, corpora)
    if sc:
        json.dump(sc, open(OUT / "scale_v10.json", "w"), default=float)
    print(f"[scale] done {time.time()-t0:.0f}s", flush=True)

    co = stage("cost", cost_experiments, corpora)
    if co:
        json.dump(co, open(OUT / "cost_v10.json", "w"), indent=2, default=float)
    print(f"ALL DONE {time.time()-t0:.0f}s", flush=True)


# ======================= validation-split tuning =======================
def _sel_eval(name, corpora, seed, cfg, n_rounds=N_ROUNDS):
    """Train FedAdaW with cfg and return (validation, test) metrics."""
    dim = corpora[name]['X'].shape[1]
    Xtr, ytr, Xva, yva, Xte, yte, ncl = prep_corpus(name, corpora, None, 'dir0.1', seed)
    g, _, _ = run('FedAdaW', Xtr, ytr, dim, seed, n_rounds=n_rounds, **cfg)
    return ev(g, Xva, yva), ev(g, Xte, yte)


def tune_stage(corpora, stage, corpora_to_tune=None, seeds=None):
    """Coordinate search on the validation split.  stage in {beta, server, lam}."""
    names = corpora_to_tune or ['StudentDropout', 'OnlineTutorBehaviour', 'CrossCorpus']
    seeds = seeds or [42, 43]
    grids = {
        'beta':   [dict(beta=b, lam=LAM_ALIGN, server_lr=1.0, server_mom=0.9, scale_mode='norm')
                   for b in [0.5, 1.0, 2.0, 4.0, 8.0, 16.0]],
        'server': [dict(beta=None, lam=LAM_ALIGN, server_lr=lr, server_mom=sm, scale_mode=md)
                   for (md, lr, sm) in [('norm', 1.0, 0.9), ('lr', 1.0, 0.9),
                                        ('lr', 1.0, 0.5), ('lr', 0.3, 0.9), ('lr', 0.1, 0.9)]],
        'lam':    [dict(beta=None, lam=l, server_lr=None, server_mom=None, scale_mode=None)
                   for l in [0.01, 0.0, 0.05]],
    }[stage]
    out = {}
    for name in names:
        for s in seeds:
            for gi, gcfg in enumerate(grids):
                cfg = dict(gcfg)
                cur = dict(CFG.get(name, {}))
                for k in ('beta', 'lam', 'server_lr', 'server_mom', 'scale_mode'):
                    if cfg.get(k) is None:
                        cfg[k] = cur.get(k, dict(beta=BETA, lam=LAM_ALIGN, server_lr=1.0,
                                                 server_mom=0.9, scale_mode='norm')[k])
                v, t = _sel_eval(name, corpora, s, cfg)
                key = f"{name}|{stage}|{gi}|{json.dumps(cfg, sort_keys=True)}"
                out.setdefault(key, []).append(dict(seed=s, cfg=cfg,
                                                    val_ba=v['balanced_accuracy'],
                                                    val_acc=v['accuracy'],
                                                    test_ba=t['balanced_accuracy'],
                                                    test_acc=t['accuracy']))
                print(f"[tune:{stage}] {name} s{s} {cfg} valBA={v['balanced_accuracy']:.4f} "
                      f"testBA={t['balanced_accuracy']:.4f}", flush=True)
    return out


def apply_selected(tuned):
    """Pick, per corpus, the configuration with the best mean validation score."""
    best = {}
    for key, rows in tuned.items():
        name = key.split('|')[0]
        cfg = rows[0]['cfg']
        v = float(np.mean([r['val_ba'] for r in rows]))
        if name not in best or v > best[name][0]:
            best[name] = (v, cfg)
    for name, (v, cfg) in best.items():
        CFG[name] = cfg
        print(f"[select] {name}: valBA={v:.4f} -> {cfg}", flush=True)
    return {k: dict(val_ba=v, cfg=c) for k, (v, c) in best.items()}
