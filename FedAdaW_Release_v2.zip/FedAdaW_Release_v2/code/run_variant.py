"""Run one ablation variant across all corpora and seeds, so that a corrected rule
can be reported in the main comparison.

usage: run_variant.py <variant> <tag> <corpora_csv> <seeds_csv> <n_rounds>
"""
from pathlib import Path
import importlib.util, sys, json, os, time
import numpy as np

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

BASE = Path(__file__).resolve().parent.parent      # repository root
spec = importlib.util.spec_from_file_location("pv12", Path(__file__).resolve().parent / "pipeline_v12.py")
m = importlib.util.module_from_spec(spec)
sys.modules["pv12"] = m
spec.loader.exec_module(m)

variant = sys.argv[1]
tag = sys.argv[2]
corp = sys.argv[3].split(",") if len(sys.argv) > 3 and sys.argv[3] else None
if len(sys.argv) > 4 and sys.argv[4]:
    m.SEEDS = [int(x) for x in sys.argv[4].split(",")]
if len(sys.argv) > 5 and sys.argv[5]:
    m.N_ROUNDS = int(sys.argv[5])

OUTROOT = os.environ.get("OUTROOT", "results")
m.OUT = m.BASE / OUTROOT
m.OUT.mkdir(exist_ok=True)
OUT = m.OUT / tag
OUT.mkdir(parents=True, exist_ok=True)
m.OUT = OUT

for f in sorted((m.BASE / OUTROOT).glob("**/tune_v12_*.json")):
    try:
        d = json.load(open(f, encoding="utf-8"))
        m.CFG[d["corpus"]] = d["cfg"]
    except Exception:
        pass
FALLBACK = m.CFG.get('StudentDropout')
if FALLBACK:
    for c in m.CORPORA_ORDER:
        m.CFG.setdefault(c, dict(FALLBACK))

t0 = time.time()
corpora = m.build_corpora()
names = corp or [c for c in m.CORPORA_ORDER if c in corpora]
res = {}
for name in names:
    dim = corpora[name]['X'].shape[1]
    for s in m.SEEDS:
        Xtr, ytr, Xva, yva, Xte, yte, ncl = m.prep_corpus(name, corpora, None, 'dir0.1', s)
        g = m._run_variant(variant, Xtr, ytr, dim, s, **m.cfg_for(name))
        rec = dict(m.ev(g, Xte, yte))
        rec['_seed'] = s
        res.setdefault(f"{name}|{variant}", []).append(rec)
    print(f"[variant:{variant}] {name} done {time.time()-t0:.0f}s", flush=True)

json.dump(res, open(OUT / f"variant_{tag}.json", "w"), default=float)
print(f"[variant] {variant}/{tag} done {time.time()-t0:.0f}s", flush=True)
