#!/usr/bin/env python3
"""Driver for pipeline_v12: loads the validation-selected per-corpus configuration
then runs one stage.

usage: run_v11_driver.py <stage> <tag> [corpora_csv] [seeds_csv] [n_rounds]
"""
from pathlib import Path
import importlib.util, sys, json, os, time

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

BASE = Path(__file__).resolve().parent.parent      # repository root
spec = importlib.util.spec_from_file_location("pv12", Path(__file__).resolve().parent / "pipeline_v12.py")
m = importlib.util.module_from_spec(spec)
sys.modules["pv12"] = m
spec.loader.exec_module(m)

stage = sys.argv[1]
tag = sys.argv[2]
corp = sys.argv[3].split(",") if len(sys.argv) > 3 and sys.argv[3] else None
if len(sys.argv) > 4 and sys.argv[4]:
    m.SEEDS = [int(x) for x in sys.argv[4].split(",")]
if len(sys.argv) > 5 and sys.argv[5]:
    m.N_ROUNDS = int(sys.argv[5])

OUTROOT = os.environ.get("OUTROOT", "results")
m.OUT = m.BASE / OUTROOT
m.OUT.mkdir(exist_ok=True)
OUT = m.OUT / tag
OUT.mkdir(parents=True, exist_ok=True)
m.OUT = OUT

# load the validation-selected configuration (defaults if not yet tuned)
CFGDIR = m.BASE / OUTROOT
found = []
for root in (CFGDIR, m.BASE / "results"):
    for f in sorted(root.glob("**/tune_v12_*.json")):
        try:
            d = json.load(open(f, encoding="utf-8"))
            m.CFG[d["corpus"]] = d["cfg"]
            found.append(d["corpus"])
        except Exception as e:
            print("cfg load skip", f, e, flush=True)
print("tuned configs loaded for:", sorted(set(found)), flush=True)
print("CFG (tuned):", json.dumps(m.CFG, sort_keys=True), flush=True)

# Corpora whose test split is too small to support hyperparameter selection reuse
# the configuration selected on the dropout corpus; this is stated in Section 4.4.
FALLBACK = m.CFG.get('StudentDropout')
if FALLBACK:
    for c in m.CORPORA_ORDER:
        if c not in m.CFG:
            m.CFG[c] = dict(FALLBACK)
    print("CFG (after fallback):", json.dumps(m.CFG, sort_keys=True), flush=True)

t0 = time.time()
corpora = m.build_corpora()
if corp:
    m.CORPORA_ORDER = [c for c in corp if c in corpora]

if stage == "main":
    res, curves, diags, meta = m.main_experiments(corpora)
    json.dump(res, open(OUT / f"results_{tag}.json", "w"), default=float)
    json.dump(curves, open(OUT / f"curves_{tag}.json", "w"), default=float)
    json.dump(diags, open(OUT / f"diag_{tag}.json", "w"), default=float)
    json.dump(meta, open(OUT / f"meta_{tag}.json", "w"), default=float)
elif stage == "abl":
    json.dump(m.ablation_experiments(corpora), open(OUT / f"ablation_{tag}.json", "w"), default=float)
elif stage == "het":
    json.dump(m.hetero_experiments(corpora), open(OUT / f"hetero_{tag}.json", "w"), default=float)
elif stage == "scale":
    json.dump(m.scale_experiments(corpora), open(OUT / f"scale_{tag}.json", "w"), default=float)
elif stage == "cost":
    json.dump(m.cost_experiments(corpora), open(OUT / f"cost_{tag}.json", "w"), indent=2, default=float)
else:
    raise SystemExit("unknown stage " + stage)

print(f"[driver11] {stage}/{tag} done {time.time()-t0:.0f}s", flush=True)
