"""Merge the per-job result files into consolidated files, deduplicated by seed.

The pipeline writes two files per job: its own accumulating dump (results_v10.json,
curves_v10.json, ...) and the driver's per-job copy (results_<tag>.json).  Only the
per-job copies are merged, and every record is tagged with its seed so that a seed
can never be counted twice.
"""
import json, re, sys
from pathlib import Path
import numpy as np

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else
            Path(__file__).resolve().parent.parent / "results")
OUTD = ROOT.parent / (ROOT.name + "_merged")
OUTD.mkdir(exist_ok=True)

FAM = {
    'results': 'results_v10', 'curves': 'curves_v10', 'diag': 'diag_v10',
    'meta': 'meta_v10', 'ablation': 'ablation_v10', 'hetero': 'hetero_v10',
    'scale': 'scale_v10', 'fair': 'fair_v10', 'cost2': 'cost2_v10',
    'cost': 'cost_v10', 'variant': 'variant_v10',
}

# merged[family][key] = {seed: value}
merged = {}
skipped = []


def add(fam, key, seed, val):
    d = merged.setdefault(fam, {}).setdefault(key, {})
    if seed in d:
        skipped.append((fam, key, seed))
    d[seed] = val


for sub in sorted(ROOT.iterdir()):
    if not sub.is_dir() or sub.name == 'logs':
        continue
    for f in sorted(sub.glob('*.json')):
        stem = f.stem
        seed = None
        corpus = None
        if stem in FAM:
            fam, seed = FAM[stem], 0
        else:
            m = re.match(r'^(results|curves|diag|meta|ablation|hetero|scale|fair)_(.+?)_s(\d+)$', stem)
            if m:
                fam = FAM[m.group(1)]
                corpus, seed = m.group(2), int(m.group(3))
            elif re.match(r'^(variant)_', stem):
                fam, seed = FAM['variant'], None      # seed is carried in the record
            elif re.match(r'^(cost2?)_(cost2?)$', stem):
                fam, seed = FAM[stem.split('_')[0]], 0
            elif re.match(r'^cost2$', stem):
                fam, seed = FAM['cost2'], 0
            else:
                continue
        try:
            d = json.load(open(f, encoding='utf-8'))
        except Exception as e:
            print("skip (unreadable)", f, e)
            continue
        for k, v in d.items():
            if fam == 'curves_v10' and isinstance(v, list):
                add(fam, k, seed, v)          # a curve is one record per seed
            elif fam == 'variant_v10' and isinstance(v, list):
                # records are written in seed order; older runs carry no _seed field
                for i, item in enumerate(v):
                    add(fam, k, int(item.get('_seed', 42 + i)), item)
            elif isinstance(v, list):
                for item in v:
                    if isinstance(item, dict):
                        item = dict(item)
                        item['_seed'] = seed
                    add(fam, k, seed, item)
            elif isinstance(v, dict):
                vv = dict(v)
                vv['_seed'] = seed
                add(fam, k, seed, vv)
            else:
                add(fam, k, seed, v)

# export: a key that exists for a single seed keeps its own shape (dict or list);
# a key with several seeds becomes a list of per-seed records.
for fam, keys in merged.items():
    out = {}
    for k, byseed in keys.items():
        vals = [byseed[s] for s in sorted(byseed)]
        out[k] = vals[0] if len(vals) == 1 else vals
    json.dump(out, open(OUTD / f"{fam}.json", "w"), indent=1, default=float)
    print(f"{fam}: {len(out)} keys")

print("duplicate (family, key, seed) collisions:", len(skipped))
for s in skipped[:5]:
    print("   ", s)
print("merged ->", OUTD)

# hard check: no cell may hold two records for the same seed with different values
bad = []
for fam, keys in merged.items():
    for k, byseed in keys.items():
        seen = {}
        for s, v in byseed.items():
            sig = json.dumps(v, sort_keys=True, default=float)
            if s in seen and seen[s] != sig:
                bad.append((fam, k, s))
            seen[s] = sig
print("cells with conflicting duplicate seeds:", len(bad), bad[:5])

# sanity report
res = merged.get('results_v10', {})
if res:
    ns = sorted({len(v) for v in res.values()})
    print("records per cell:", ns)
    for k in list(res)[:3]:
        print("  ", k, "seeds:", sorted(res[k]))
