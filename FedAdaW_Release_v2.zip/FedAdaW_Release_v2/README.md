# Preprocessed educational corpora and federated-learning experiment results for student performance prediction under severe data heterogeneity

This repository accompanies a study of **distribution-aware aggregation in federated
learning for student performance prediction**, evaluated on four real educational
corpora and on a cross-corpus federation under three non-IID partitioning protocols.

Everything needed to reproduce the reported numbers is here: the preprocessed corpora,
the federated learning pipeline with all nine methods, the hyperparameter selection
procedure, the label-leakage audit, the per-seed result files, and the scripts that
generate every table and figure.

## Layout

```
code/
  pipeline_v12.py             federated learning pipeline: data builders, partitioning,
                              sliced Wasserstein-2 aggregation, all baselines, diagnostics
  run_experiment.py           runs one (stage, corpus, seed) slice
  tune_hyperparameters.py     coordinate search of the proposed rule's hyperparameters
                              on the validation split
  run_variant.py              runs one ablation variant across all corpora and seeds
  run_fairness_and_cost.py    per-client local-holdout evaluation, cost and scale studies
  merge_results.py            merges per-job JSON into one file per result family,
                              deduplicated by seed
  audit_label_leakage.py      single-feature threshold-classifier audit of every corpus
  make_figures.py             regenerates the six figures from the merged results
data/
  preprocessed/*.csv          the corpora after preprocessing (features, label, and for
                              the cross-corpus federation the source corpus of each row)
  config/tune_v12_*.json      the hyperparameters selected on the validation split
results/
  merged/*.json               consolidated results: main comparison, ablation,
                              heterogeneity, scale, fairness, cost, per-round diagnostics
  per_seed/*.json             the raw per-seed files from which the merged files are built
figures/*.png                 the six figures of the paper
```

## Corpora

| Corpus | Records | Task (label) |
|---|---|---|
| StudentDropout | 4,424 | graduation vs non-graduation (UCI 697) |
| SecondaryGrades | 649 | final grade G3 >= 10, predicted from the first and second period grades (UCI 320) |
| EntranceExam | 666 | top-two examination bands, predicted from prior-education bands (UCI 582) |
| OnlineTutorBehaviour | 5,058 | later-half vs earlier-half correctness on a chronological split |
| HigherEdEval | 145 | characterisation only; not used for any conclusion (UCI 856) |
| CrossCorpus | 10,797 | the four training corpora federated under one shared seven-indicator schema |

Raw data are public: UCI Machine Learning Repository datasets 697, 320, 582 and 856, and
the ASSISTments 2015 release. Only the preprocessed, de-identified derivatives are
redistributed here.

Two points about the construction are worth stating because they are easy to get wrong.
First, no label is a function of an input feature: `audit_label_leakage.py` fits the best
single-feature threshold classifier to every corpus and reports its balanced accuracy, and
the manuscript reports those values. Second, the tutoring corpus is labelled by a
chronological split, so every feature is measured strictly before the outcome.

## Reproducing

```bash
pip install -r requirements.txt

# label-leakage audit (fast)
python code/audit_label_leakage.py

# hyperparameter selection on the validation split (three corpora)
python code/tune_hyperparameters.py StudentDropout 42,43

# the main comparison, one job per (corpus, seed); 112 jobs in total
python code/run_experiment.py main StudentDropout_s42 StudentDropout 42 30

# consolidate and plot
python code/merge_results.py results
python code/make_figures.py results/merged figures
```

Each experiment writes its own JSON, so jobs can be run in parallel and resumed.

## Notes on the results

The study reports where the proposed rule is ahead and where it is behind, and the
ablation identifies which ingredients of the aggregation actually move accuracy. The
merged files are the single source of every number in the paper: the manuscript's tables,
figures and abstract are generated from them, so they cannot disagree.

## Licence and citation

Code is released under the MIT licence; the preprocessed data derivatives are released
under CC BY 4.0, consistent with the licences of the source datasets. See `CITATION.cff`.
