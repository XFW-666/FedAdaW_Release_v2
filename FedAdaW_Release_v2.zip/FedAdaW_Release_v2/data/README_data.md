# Data provenance

## Preprocessed derivatives (`preprocessed/`)

| File | Rows | Columns | Notes |
|---|---|---|---|
| StudentDropout.csv | 4,424 | 7 features + label | label 1 = graduated |
| SecondaryGrades.csv | 649 | 7 features + label | label 1 = final grade G3 >= 10; the level and trend indicators use the second period grade G2 and G2 - G1, so the label is not recoverable from any input |
| EntranceExam.csv | 666 | 7 features + label | label 1 = top-two examination bands; the level and trend indicators use the prior-education bands |
| OnlineTutorBehaviour.csv | 5,058 | 7 features + label | every feature is computed from the chronological first half of a student's interaction log and the label is whether the later half improves on the earlier half |
| HigherEdEval.csv | 145 | 7 features + label | characterisation only; not used for any conclusion |
| CrossCorpus.csv | 10,797 | 7 features + label + source_corpus | the four training corpora under one shared schema, each row carrying the corpus it came from |

The seven shared indicators are: engagement_volume, engagement_consistency,
performance_level, performance_trend, effort_per_unit, prior_difficulty,
demographic_advantage.  No padding is used; every indicator is defined in every corpus.

`code/audit_label_leakage.py` fits the best single-feature threshold classifier to each
corpus and prints its balanced accuracy.  That audit is what motivated the construction of
the level and trend indicators described above.

## Raw inputs (not redistributed)

Place these files in `data/raw/` to rebuild the derivatives from scratch:

| Expected file name | Source |
|---|---|
| dropout_prediction.csv | UCI Machine Learning Repository, dataset ID 697 |
| student_performance.csv | UCI Machine Learning Repository, dataset ID 320 |
| entrance_exam.csv | UCI Machine Learning Repository, dataset ID 582 |
| higher_edu_performance.csv | UCI Machine Learning Repository, dataset ID 856 |
| assist2015.csv | ASSISTments 2015 public release |

UCI datasets are available under CC BY 4.0 at https://archive.ics.uci.edu/ .  The
ASSISTments 2015 release is available from the ASSISTments project under its own terms.
